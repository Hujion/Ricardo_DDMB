//
//  ViewController.swift
//  RicardoCorreia_DDMB_RGB-T2
//
//  Created by Ricardo Correia on 30/05/2019.
//  Copyright © 2019 Ricardo. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    
    
    
    var labelcolor:UILabel?
    
    var labelrgba:UILabel?
    
    var labelvermelho:UILabel?
    
    var labelverde:UILabel?
    
    var labelazul:UILabel?
    
    var labeltrans:UILabel?
    
    
    
    var Vermelho = 0;
    
    var Verde = 0;
    
    var Azul = 0;
    
    var Trans = 255;
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad();
        
        
        
        
        
        labelcolor = UILabel(frame: CGRect(x: 150, y: 100, width: 300, height: 300));
        
        labelcolor?.center.x = self.view.center.x;
        
        
        
        labelrgba = UILabel(frame: CGRect(x: 75, y: 400, width: 350, height:50));
        
        labelrgba?.text = "Vermelho: \(Vermelho) Verde: \(Verde) Azul: \(Azul) Trans: \(Trans)";
        
        
        
        
        
        let colorRed = UISlider(frame: CGRect(x: 100, y: 500, width: 200, height: 80));
        colorRed.minimumValue = 0;
        colorRed.maximumValue = 255;
        colorRed.addTarget(self, action: #selector(toRed), for: .valueChanged);
        
        
        
        let colorGreen = UISlider(frame: CGRect(x: 100, y: 550, width: 200, height: 80));
        colorGreen.minimumValue = 0;
        colorGreen.maximumValue = 255;
        colorGreen.addTarget(self, action: #selector(toGreen), for: .valueChanged);
        
        
        
        let colorBlue = UISlider(frame: CGRect(x: 100, y: 600, width: 200, height: 80));
        colorBlue.minimumValue = 0;
        colorBlue.maximumValue = 255;
        colorBlue.addTarget(self, action: #selector(toBlue), for: .valueChanged);
        
        
        
        let colorAlpha = UISlider(frame: CGRect(x: 100, y: 650, width: 200, height: 80));
        colorAlpha.minimumValue = 0;
        colorAlpha.maximumValue = 255;
        colorAlpha.addTarget(self, action: #selector(toAlpha), for: .valueChanged);
        
        
        
        
        
        self.view.addSubview(labelcolor!);
        
        self.view.addSubview(labelrgba!);
        
        self.view.addSubview(labelvermelho!);
        
        self.view.addSubview(labelverde!);
        
        self.view.addSubview(labelazul!);
        
        self.view.addSubview(labeltrans!);
        
        self.view.addSubview(colorRed);
        
        self.view.addSubview(colorGreen);
        
        self.view.addSubview(colorBlue);
        
        self.view.addSubview(colorAlpha);
        
    }
    
    
    
    @objc func toRed (_ sender:UISlider){
        Vermelho = Int(sender.value);
        toCallColor();
    }
    
    
    
    @objc func toGreen (_ sender:UISlider){
        Verde = Int(sender.value);
        toCallColor();
        
    }
    
    
    
    @objc func toBlue(_ sender:UISlider){
        Azul = Int(sender.value);
        toCallColor();
        
    }
    
    
    
    @objc func toAlpha(_ sender:UISlider){
        Trans = Int(sender.value);
        toCallColor();
    }
    
    
    
    @objc func ResultadoRGB(){
        
        labelcolor?.backgroundColor = UIColor(red: CGFloat(Vermelho)/255, green: CGFloat(Verde)/255, blue: CGFloat(Azul)/255, alpha: CGFloat(Trans)/255);
        
        labelrgba?.text = "Vermelho: \(String(Vermelho)) Verde: \(String(Verde)) Azul: \(String(Azul)) Trans: \(String(Trans))";
        
        
        
    }
    
    
    
}

